package com.projitize.apcodelearner.utils

const val TAG = "APLearner"
const val collectionUser = "UsersData"
const val collectionQA = "QA"
const val collectionReference = "Reference"
const val collectionMiniProject = "MiniProject"
const val collectionQuiz = "Quiz"
const val collectionFeedback = "Feedback"
const val collectionTutorial = "Tutorial"