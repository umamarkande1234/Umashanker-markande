package com.projitize.apcodelearner.models

data class QaModel(
    var question: String? = null,
    var answer: String? = null,
    var time: Long? = null,
)
