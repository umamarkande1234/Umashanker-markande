package com.projitize.apcodelearner.models

data class ReferenceModel(
    var title: String? = null,
    var link: String? = null,
    var time: Long? = null,
)
