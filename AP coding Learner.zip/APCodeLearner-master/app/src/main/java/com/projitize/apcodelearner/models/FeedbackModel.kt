package com.projitize.apcodelearner.models

data class FeedbackModel(
    var feedback: String? = null,
    var name: String? = null,
    var time: Long? = null,
)
